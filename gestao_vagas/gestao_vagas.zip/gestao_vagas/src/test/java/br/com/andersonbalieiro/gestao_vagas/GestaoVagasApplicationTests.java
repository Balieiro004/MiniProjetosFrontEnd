package br.com.andersonbalieiro.gestao_vagas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoVagasApplicationTests {

	@Test
	void contextLoads() {
	}

}
